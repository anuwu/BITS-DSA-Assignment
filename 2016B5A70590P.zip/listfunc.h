extern void create_list () ;
extern void insert_ele (int listno, int key) ;
extern void delete_ele (int listno, int key) ;
extern void no_ele_list (int listno) ;
extern void display_list (struct list *ptr) ;
extern void display_all_lists () ;
extern void display_free_list () ;
