extern int* create_free_list (int ram_size) ;

extern void display_ram (int *ptr) ;

extern void initialise () ;

extern void free_all () ;
