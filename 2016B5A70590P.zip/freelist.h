extern void pop_free_list () ;
extern void push_free_list (int push_index) ;
