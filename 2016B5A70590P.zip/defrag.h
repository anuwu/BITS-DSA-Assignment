extern int first_used_from_right () ;
extern struct list* findlist (int fufr_index) ;
extern void defrag () ;
