struct list
{
	int head ;
	int no_ele ;
	struct list *next ;
} ;

